<!Doctype html>
<html>
<head>
          <meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script type="jsbin" src="jquery/jquery-3.2.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/css.css">
    <title>Cadastro</title>
      <style type="text/css">
      </style>
</head>

<body>
<div class=login-page>
  <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navbar">
  <a class="navbar-brand" href="home.php">Home</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav">

      <li class="nav-item">
        <a class="nav-link" href="cadastrarfuncionario.php">Cadastrar funcionario</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Cadastrar Cardaprio</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Pedido</a>
      </li>
    </ul>
  </div>
</nav>

<div id="login">
  <img src="img/user.png"></br>
    <h1>Cadastrar</h1>

    <form action="validarcad_func.php" method="POST">
    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Nome</label>
        <input type="text" class="form-control" id="nome" placeholder="Digite o nome" name="nome">
      </div>
      <div class="form-group col-md-6">
        <label>Sobrenome</label>
        <input type="text" class="form-control" id="sobrenome" placeholder="Digite o sobrenome" name="sobrenome">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group col-md-6">
        <label>Endereço</label>
        <input type="text" class="form-control" id="endereco" placeholder="Digite o Endereço" name="endereco">
      </div>
      <div class="form-group col-md-2">
        <label>Número</label>
        <input type="number" class="form-control" id="numero" placeholder="Nº" name="numero">
      </div>
      <div class="form-group col-md-4">
        <label>CPF</label>
        <input type="text" class="form-control" id="cpf" placeholder="Digite seu CPF" name="cpf">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group col-md-5">
        <label for="inputCity">Cidade</label>
        <input type="text" class="form-control" id="cidade" placeholder="Digite o nome da Cidade" name="cidade">
      </div>

      <div class="form-group col-md-4">
        <label for="inputState">Estado</label>
        <select id="estado"  class="form-control" name="estado">
          <option selected>Acre</option> <option selected>Alagoas</option> <option selected>Amapá</option>
          <option selected>Amazonas</option> <option selected>Bahia</option> <option selected>Ceará</option>
          <option selected>Distrito Federal</option> <option selected>Espírito Santo</option> <option selected>Goiás</option>
          <option selected>Maranhão</option> <option selected>Mato Grosso</option> <option selected>Mato Grosso do Sul</option>
          <option selected>Minas Gerais</option> <option selected>Pará</option> <option selected>Paraíba</option>
          <option selected>Paraná</option> <option selected>Pernambuco</option> <option selected>Piauí</option>
          <option selected>Rio de Janeiro</option> <option selected>Rio Grande do Norte</option> <option selected>Rio Grande do Sul</option>
          <option selected>Rondônia</option> <option selected>Roraima</option> <option selected>Santa Catarina</option>
          <option selected>São Paulo</option> <option selected>Sergipe</option><option>Tocantins</option><option selected>Selecione</option>
          <option></option>
        </select>
      </div>

      <div class="form-group col-md-3">
        <label>CEP</label>
        <input type="text" class="form-control" id="cep" placeholder="CEP" name="cep">
      </div>

    </div>


    <button type="submit" class="btn btn-primary">Cadastrar</button>
  </form>
  </div>
</div>


</body>
</html>
