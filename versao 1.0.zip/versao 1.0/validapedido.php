<!DOCTYPE html>
<html>
<head>
	<title>Validação Pedido</title>
</head>
<body>
	<center>Pedido efetuado com sucesso! <br>
		<a href="caditens.php">Voltar</a>
	</center>
</body>
</html>