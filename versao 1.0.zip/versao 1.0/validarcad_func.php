
<?php

    //Criacação de uma instância de objeto,
    //passando como par a string de conexão, o usuário e a senha
    try{
      $con = new PDO("mysql:host=localhost;dbname=bd_trabalho", 'root'); //'iria a senha root'//
    }catch(PDOExcepetion $e){
      echo 'Falha na Conexão: ' . $e->getMessage();
    }

    $cad_funcionario = $_POST;
    $sql = "INSERT INTO cad_funcionario(nome, sobrenome, endereco, numero, cidade, estado, cpf, cep) "
          ." VALUES(:nome, :sobrenome, :endereco, :numero, :cidade, :estado, :cpf, :cep)";
    $query = $con->prepare($sql);
    if($query->execute($cad_funcionario)) echo "Cadastrado com Sucesso";
    else echo "Erro ao cadastrar";
   // echo "$sql";


?>
