<?php 
	
	//var_dump($_POST);

	$usuario = $_POST ['user'];
	$senha = $_POST ['senha'];
	$botao1 = isset($_POST ['radio1'])? true:false;
	$botao2 = isset($_POST ['radio2'])? true:false;

if($botao1==true){
	if($usuario==("admin")&&$senha==("admin")){
		header('location: home.php');
	}else
	echo "USUARIO OU SENHA INCORRETO!!";
	
}

if($botao2==true){
	if($usuario==("funcionario")&&$senha==("func")){
		echo "LOGIN EFETUADO COM SUCESSO!! ";
	}else
	echo "USUARIO OU SENHA INCORRETO!!";
	
}

?>