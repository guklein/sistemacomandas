<!DOCTYPE html>
<html>
<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
			</script>

            <script type="jsbin" src="jquery/jquery-3.2.1.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/css.css">		
	<title>Cadastro Cardaprio</title>
</head>
<body>
			<div class=login-page>
						<div>		
							<nav class="navbar navbar-expand-lg navbar-light bg-light" id="navbar">
							  <a class="navbar-brand" href="home.php">Home</a>
							  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
							    <span class="navbar-toggler-icon"></span>
							  </button>
							  <div class="collapse navbar-collapse">
							    <ul class="navbar-nav">

							      <li class="nav-item">
							        <a class="nav-link" href="cadastrarfuncionario.php">Cadastrar funcionario</a>
							      </li>
							      <li class="nav-item">
							        <a class="nav-link" href="caditens.php">Cadastrar Cardaprio</a>
							      </li>
							      <li class="nav-item">
							        <a class="nav-link" href="pedido.php">Pedido</a>
							      </li>
							    </ul>
							  </div>
							</nav>
						</div>	

	<div id="login"></div>
		 <center><h1>Cadastrar Itens</h1></center>

	    <form action="validaitens.php">
	    <div class="form-row">
	      <div class="form-group col-md-4">
	        <label>Produto</label>
	        <input type="text" class="form-control" id="nome" placeholder="Digite o nome" name="nome">
	      </div>
	      <div class="form-group col-md-4">
	        <label>Categoria</label>
	          <select id="categoria"  class="form-control" name="categoria">
	          <option selected>Lanches</option> <option selected>Pizzas</option> <option selected>Cervejas</option>
	          <option selected>Refrigerantes</option> <option selected>Chopp</option>
	           <option selected>Selecione</option>	         
	        </select>
	      </div>
	    </div>

	    <div class="form-row">
	      <div class="form-group col-md-4">
	        <label>Descrição</label>
	        <input type="text" class="form-control" id="descricao" placeholder="Descrição" name="descricao">
	      </div>
	      <div class="form-group col-md-4">
	        <label>Preço</label>
	        <input type="number" class="form-control" id="preco" placeholder="Preço" name="preco">
	      </div>
	    </div>


	   <center><button type="submit" class="btn btn-primary">Cadastrar</button></center>
	  </form>
	  </div>
</body>
</html>