<!DOCTYPE html>
<html>
<head>
    <script type="jsbin" src="jquery/jquery-3.2.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/css.css">
	<title>Login</title>
		  <meta charset="utf-8">
		  <meta name="viewport" content="width=device-width, initial-scale=1">
		  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
	<body>
		<div class="login-page">
			<center>
			  <div>
				<center><h1>Sistema Comandas</h1></center>
				<form action="validauser.php" method="POST">
							<div class="form-check form-check-inline">
							  <input class="form-check-input" type="radio" name="radio1" id="radio1">
							  <label class="form-check-label" for="radio1"> Administrador</label>
							</div>
							<div class="form-check form-check-inline">
							  <input class="form-check-input position-static" type="radio" name="radio2" id="radio2">
							  <label class="form-check-label" for="radio2"> Funcionário</label>
							</div>
			</center>

					  <div class="container">
					    <label for="exampleInputEmail1">Usuário</label>
					    <input type="user" class="form-control" id="user" aria-describedby="emailHelp" name="user" placeholder="Informe Usuário" required>
					  </div>
					  <div class="container">
					    <label for="exampleInputPassword1">Senha</label>
					    <input type="password" class="form-control" id="senha" placeholder="Senha" name="senha" required>
					  </div>
					  </br>
					 <center><button  type="submit" class="btn btn-primary">Entrar</button></center>
				</form>
		</div>
  			</div>
 	</body>
</html>