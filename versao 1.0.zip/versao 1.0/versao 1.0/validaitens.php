<!DOCTYPE html>
<html>
<head>
	<title>Validação itens</title>
</head>
<body>
	<center>Item Cadastrado com sucesso! <br>
		<a href="caditens.php">Voltar</a>
	</center>
</body>
</html>